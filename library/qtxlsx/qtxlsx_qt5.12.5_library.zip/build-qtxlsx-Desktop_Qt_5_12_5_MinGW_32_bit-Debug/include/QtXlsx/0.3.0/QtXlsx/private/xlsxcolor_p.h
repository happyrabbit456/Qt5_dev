#include "../../../../../../QtXlsxWriter/src/xlsx/xlsxcolor_p.h"
