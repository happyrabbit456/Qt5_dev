#include "../../../QtXlsxWriter/src/xlsx/xlsxconditionalformatting.h"
