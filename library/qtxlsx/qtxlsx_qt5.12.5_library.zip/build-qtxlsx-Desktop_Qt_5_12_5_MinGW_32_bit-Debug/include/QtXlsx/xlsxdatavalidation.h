#include "../../../QtXlsxWriter/src/xlsx/xlsxdatavalidation.h"
